//Game state
int state = 0; 

int startTime;
int duration = 30;

//Player
float px = 350, py = 250;
float vx = 0, vy = 0;

float accel = 0.6;
float friction = 0.9;
float gravity = 0.6;
float jumpForce = -12;

float pR = 20;
float groundY = 300;

//Enemies
int n = 8;

float[] ex = new float[n];
float[] ey = new float[n];
float[] evx = new float[n];
float[] evy = new float[n];

float eR = 15;

int lives = 3;

boolean canHit = true;
int lastHitTime = 0;
int hitCooldownMs = 800;

void setup() {
  size(700, 350);

  //initialize enemies
  for (int i = 0; i < n; i++) {
    ex[i] = random(eR, width - eR);
    ey[i] = random(eR, height - eR);

    evx[i] = random(-3, 3);
    evy[i] = random(-3, 3);

    if (abs(evx[i]) < 1) evx[i] = 2;
    if (abs(evy[i]) < 1) evy[i] = -2;
  }
}

void draw() {

  background(240);

  if (state == 0) {
    textAlign(CENTER, CENTER);
    textSize(26);
    fill(0);
    text("Press ENTER to Start", width/2, height/2);
  }

  else if (state == 1) {

    int elapsed = (millis() - startTime) / 1000;
    int left = duration - elapsed;

    if (left <= 0) {
      state = 3; // WIN
    }

    //Player movement (Accel)
    if (keyPressed) {
      if (keyCode == RIGHT) vx += accel;
      if (keyCode == LEFT)  vx -= accel;
    }

    vx *= friction;

    vy += gravity;

    //Position update
    px += vx;
    py += vy;

    //Ground collision
    if (py > groundY) {
      py = groundY;
      vy = 0;
    }

    //Keep in Screen
    px = constrain(px, pR, width - pR);

    //Draw player
    fill(60, 120, 220);
    ellipse(px, py, pR*2, pR*2);

    //Enemies
    for (int i = 0; i < n; i++) {

      // move
      ex[i] += evx[i];
      ey[i] += evy[i];

      // bounce
      if (ex[i] > width - eR || ex[i] < eR) evx[i] *= -1;
      if (ey[i] > height - eR || ey[i] < eR) evy[i] *= -1;

      // draw
      fill(255, 90, 120);
      ellipse(ex[i], ey[i], eR*2, eR*2);

      // Collison
      float d = dist(px, py, ex[i], ey[i]);

      if (d < pR + eR && canHit) {
        lives--;
        canHit = false;
        lastHitTime = millis();

        if (lives <= 0) {
          state = 2; // GAME OVER
        }
      }
    }

    if (!canHit && millis() - lastHitTime > hitCooldownMs) {
      canHit = true;
    }

    fill(0);
    textAlign(LEFT, TOP);
    textSize(16);
    text("Lives: " + lives, 20, 20);
    text("Time: " + left, 20, 40);

    // ground line
    line(0, groundY + pR, width, groundY + pR);
  }

  else if (state == 2) {
    textAlign(CENTER, CENTER);
    textSize(26);
    fill(0);
    text("GAME OVER\nPress R to Restart", width/2, height/2);
  }

  else if (state == 3) {
    textAlign(CENTER, CENTER);
    textSize(26);
    fill(0);
    text("YOU WIN!\nPress R to Restart", width/2, height/2);
  }
}

void keyPressed() {

  if (state == 0 && keyCode == ENTER) {
    state = 1;
    startTime = millis();
    lives = 3;
  }

  // Jump
  if (state == 1 && key == ' ' && py == groundY) {
    vy = jumpForce;
  }

  if ((state == 2 || state == 3) && (key == 'r' || key == 'R')) {
    state = 0;

    px = width/2;
    py = groundY;

    vx = 0;
    vy = 0;
  }
}
